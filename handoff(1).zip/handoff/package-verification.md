# Final package checks

This delivery note supplements the [submission index](SUBMISSION.md) and [source verification record](minivm-takehome/GPT6.2-MiniVM/verification.md). It describes the package, not a change to the optimizer or to the original session evidence.

| Check | Result and scope |
|---|---|
| Previous archive, reviewer’s Linux extraction | The scripts were stored as `0666`; direct execution failed until `chmod +x`. With permissions restored and the vendor VM supplied locally, 10 unit tests and all 12 evaluator cases passed. The identity control passed; the duplicate-loss control exited 1. The evaluator took approximately **0.48 s**. The previously reported **0.67 s** was a separate run from restored Git history. |
| Corrected archive | Both launchers and both evaluator controls have Unix mode `100755` (regular file with permissions `0755`). A fresh Windows/Git Bash extraction ran without `chmod` or Git checkout, using the vendor VM only in the temporary test directory. This is not a native Linux retest of the corrected ZIP. |
| Performance | **60,363 to 51,640 cycles**: 8,723 fewer, or **14.45% across the eight supplied queries only**. Timing and cycles are separate measures. |
| Evidence | The frozen snapshot contains the original prompts and tool output. Its 94 raw files are covered by the manifest. The approximate token count is **1,168,628** for that snapshot, not all subsequent packaging conversations. |

**Distribution:** Send the verified ZIP rather than compressing this directory again with a generic Windows archiver. Repacking identical script bytes can still discard executable permissions. See the submission index for the fallback command and history restoration instructions. The raw evidence and Git attribution retain identifying metadata; they have not been redacted.